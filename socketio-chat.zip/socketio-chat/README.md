# Real-Time Chat Application with Socket.IO

## Features
- Real-time messaging
- Multiple chat rooms
- Typing indicators
- Online user presence
- Message history

## Setup
1. Install dependencies for both server and client:
```bash
cd server && npm install
cd ../client && npm install
```

2. Start the development servers:
```bash
# In one terminal
cd server && npm start

# In another terminal
cd client && npm start
```

3. Access the application at http://localhost:3000