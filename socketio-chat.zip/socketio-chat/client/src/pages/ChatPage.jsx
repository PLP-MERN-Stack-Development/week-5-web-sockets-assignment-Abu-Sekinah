import { useState, useEffect, useRef } from 'react';
import { Box, Button, Input, VStack, Text, Heading } from '@chakra-ui/react';

export default function ChatPage({ username, socket, isConnected }) {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const [room, setRoom] = useState('general');
  const [isTyping, setIsTyping] = useState(false);
  const [typingUser, setTypingUser] = useState('');
  const messagesEndRef = useRef(null);

  useEffect(() => {
    socket.emit('join_room', room);

    socket.on('receive_message', (data) => {
      setMessages((prev) => [...prev, data]);
    });

    socket.on('typing', ({ username, isTyping }) => {
      setIsTyping(isTyping);
      setTypingUser(username);
    });

    return () => {
      socket.off('receive_message');
      socket.off('typing');
    };
  }, [room, socket]);

  const handleSendMessage = () => {
    if (message.trim()) {
      const newMessage = {
        text: message,
        sender: username,
        room,
        timestamp: new Date().toISOString()
      };
      socket.emit('send_message', newMessage);
      setMessage('');
    }
  };

  return (
    <VStack spacing={4} h="100vh" p={4}>
      <Heading>Chat Room: {room}</Heading>
      <Box flex="1" w="100%" overflowY="auto">
        {messages.map((msg, i) => (
          <Text key={i} align={msg.sender === username ? 'right' : 'left'}>
            <strong>{msg.sender}:</strong> {msg.text}
          </Text>
        ))}
        {isTyping && <Text color="gray.500">{typingUser} is typing...</Text>}
        <div ref={messagesEndRef} />
      </Box>
      <Input
        value={message}
        onChange={(e) => {
          setMessage(e.target.value);
          socket.emit('typing', { room, username, isTyping: true });
        }}
        onBlur={() => socket.emit('typing', { room, username, isTyping: false })}
        placeholder="Type a message..."
      />
      <Button onClick={handleSendMessage}>Send</Button>
    </VStack>
  );
}