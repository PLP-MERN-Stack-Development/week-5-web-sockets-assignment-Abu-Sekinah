import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Input, VStack, Heading } from '@chakra-ui/react';

export default function LoginPage({ setUsername, socket }) {
  const [name, setName] = useState('');
  const navigate = useNavigate();

  const handleLogin = () => {
    if (name.trim()) {
      setUsername(name);
      socket.auth = { username: name };
      socket.connect();
      socket.emit('new_user', name);
      navigate('/chat');
    }
  };

  return (
    <VStack spacing={4} align="center" justify="center" h="100vh">
      <Heading>Chat App</Heading>
      <Input
        placeholder="Enter your name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <Button onClick={handleLogin}>Join Chat</Button>
    </VStack>
  );
}