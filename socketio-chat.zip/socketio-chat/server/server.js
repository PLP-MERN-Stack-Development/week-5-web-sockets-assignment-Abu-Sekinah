require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
app.use(cors());
const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: "http://localhost:3000",
    methods: ["GET", "POST"]
  }
});

// Store active users and messages
const users = {};
const messages = {};

io.on('connection', (socket) => {
  console.log(`User connected: ${socket.id}`);

  // Handle new user joining
  socket.on('new_user', (username) => {
    users[socket.id] = username;
    io.emit('user_list', Object.values(users));
    socket.broadcast.emit('user_joined', username);
  });

  // Handle joining rooms
  socket.on('join_room', (room) => {
    socket.join(room);
    if (!messages[room]) messages[room] = [];
    socket.emit('message_history', messages[room]);
  });

  // Handle messages
  socket.on('send_message', (data) => {
    const room = data.room;
    messages[room] = [...(messages[room] || []), data];
    io.to(room).emit('receive_message', data);
  });

  // Handle typing indicators
  socket.on('typing', ({ room, username, isTyping }) => {
    socket.to(room).emit('typing', { username, isTyping });
  });

  // Handle disconnection
  socket.on('disconnect', () => {
    const username = users[socket.id];
    if (username) {
      delete users[socket.id];
      io.emit('user_left', username);
    }
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});